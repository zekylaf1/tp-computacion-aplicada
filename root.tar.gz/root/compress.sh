#!/bin/bash

tar -czvf /root/root.tar.gz /root
tar -czvf /root/etc.tar.gz /etc
tar -czvf /root/opt.tar.gz /opt
tar -czvf /root/www_dir.tar.gz /www_dir
tar -czvf /root/backup_dir.tar.gz /backup_dir
tar -czvf /root/var.tar.gz /var
