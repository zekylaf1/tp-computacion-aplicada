# tp-computacion-aplicada
Trabajo práctico computación aplicada

Alumnos:
 - Ezequiel Lafferriere
 - Sheyla Alarcon Canaza
 - Gisella Gamarra
 - Cristian Nahuel Raddi Orueta
 - Dante Schenone
 - Agustin Ariel Spataro
