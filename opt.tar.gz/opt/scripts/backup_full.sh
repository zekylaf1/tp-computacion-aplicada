#!/bin/bash

if [ $1 = "-help" ]; then
	echo "Uso del script: sh ./backup_full.sh </directorio_origen/> </directorio_destino/>."
	echo "Por default se utiliza /backup_dir como directorio destino"
	exit 0
fi

#Define nuevo nombre para el archivo backupeado

DEST_DIR="${2:-/backup_dir/}"
NEW_FILE_NAME="$DEST_DIR$(basename $1)_bkp_$(date +%Y%m%d).tar.gz"

echo ""
echo $NEW_FILE_NAME
echo ""

#Chequea existencia de directorios
if [ -d "$1" ] && [ -d "$DEST_DIR" ]; then
	#Procede al backup
	tar -czvf "$NEW_FILE_NAME" $1
	:
else
	echo "Origen o destino no existen"
fi
